/*
 * Copyright (c) 2000
 * Intel Corporation.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 * 
 *    This product includes software developed by Intel Corporation and
 *    its contributors.
 * 
 * 4. Neither the name of Intel Corporation or its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY INTEL CORPORATION AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL INTEL CORPORATION OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#include <setjmp.h>

int
setjmp( jmp_buf env )
{
#ifdef notdef
    _asm {
        mov     ecx, env
        mov     jmp_buf [ecx].ebx, ebx
        mov     jmp_buf [ecx].esi, esi
        mov     jmp_buf [ecx].edi, edi

        ; bugbug - this needs to be a real asm function
        mov     eax, [ebp]
        mov     jmp_buf [ecx].ebp, eax
        lea     eax, [ebp+4]
        mov     jmp_buf [ecx].esp, eax
        mov     eax, [ebp+4]
        mov     jmp_buf [ecx].eip, eax
        fnstcw	jmp_buf [ecx].fpucw
    }
#endif    
    return 0;
}

void
longjmp ( jmp_buf env, int val )
{
#ifdef notdef
	if ( val == 0 ) val = 1;
    _asm {
        mov     eax, val
        mov     ecx, env
        mov     ebx, jmp_buf [ecx].ebx
        mov     esi, jmp_buf [ecx].esi
        mov     edi, jmp_buf [ecx].edi
        mov     ebp, jmp_buf [ecx].ebp
        mov     esp, jmp_buf [ecx].esp
        fninit
        fldcw	[ecx].fpucw
        jmp     dword ptr jmp_buf [ecx].eip
    }
#endif
}
