# coldboot-tools

from "cold boot" attack tools from CITP at Princeton.
https://citp.princeton.edu/research/memory/
